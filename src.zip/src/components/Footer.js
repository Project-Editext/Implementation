export default function Footer() {
    return (
      <footer className="bg-secondary text-white p-4 text-center">
        <p>&copy; {new Date().getFullYear()} Editex. All Rights Reserved.</p>
      </footer>
    );
  }